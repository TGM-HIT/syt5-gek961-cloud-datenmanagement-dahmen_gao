package dezsys.authentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dezsys1Application {

	public static void main(String[] args) {
		SpringApplication.run(Dezsys1Application.class, args);
	}

}
